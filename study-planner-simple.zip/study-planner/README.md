# Study Planner

A clean, modern study planner built with React, Vite, TypeScript, and Tailwind CSS. All data is saved in your browser's localStorage — no backend, no setup.

## Features

- **Tasks** — add, complete, delete, and filter study tasks with priority and due dates
- **Weekly Schedule** — block out study time across the week (today is highlighted)
- **Goals** — set weekly targets for tasks completed and study hours, see live progress
- **Profile** — set your name, toggle dark mode, manage reminders, reset data
- Fully responsive (mobile + desktop)
- Dark / light theme

## Getting started

You need [Node.js 18+](https://nodejs.org).

```bash
npm install
npm run dev
```

Then open the URL shown in the terminal (usually `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview
```

The `dist/` folder contains the deployable static site.
