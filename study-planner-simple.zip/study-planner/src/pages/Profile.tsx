import { useEffect } from "react";
import { Moon, Sun, Bell, Trash2, User } from "lucide-react";
import { useLocalStorage } from "../lib/storage";

type Profile = { name: string; reminders: boolean };

export default function Profile() {
  const [profile, setProfile] = useLocalStorage<Profile>("sp_profile", { name: "", reminders: true });
  const [theme, setTheme] = useLocalStorage<"light" | "dark">("sp_theme", "light");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  function reset() {
    if (confirm("Delete all tasks, schedule, goals, and settings? This cannot be undone.")) {
      localStorage.clear();
      location.reload();
    }
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <header>
        <h1 className="text-3xl font-bold">Profile & Settings</h1>
        <p className="text-slate-600 dark:text-slate-400 mt-1">Make this planner yours.</p>
      </header>

      <section className="card p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-lg bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 flex items-center justify-center">
            <User className="w-5 h-5" />
          </div>
          <h2 className="font-bold text-lg">Profile</h2>
        </div>
        <label className="text-sm font-medium text-slate-700 dark:text-slate-300 block mb-1.5">
          Display name
        </label>
        <input
          className="input"
          placeholder="Your name"
          value={profile.name}
          onChange={(e) => setProfile({ ...profile, name: e.target.value })}
        />
      </section>

      <section className="card p-6 space-y-4">
        <h2 className="font-bold text-lg">Preferences</h2>

        <ToggleRow
          icon={theme === "dark" ? Moon : Sun}
          title="Dark mode"
          desc="Easy on the eyes during late study sessions."
          on={theme === "dark"}
          onChange={(v) => setTheme(v ? "dark" : "light")}
        />

        <ToggleRow
          icon={Bell}
          title="Reminders"
          desc="Show alerts on the home page for tasks due soon."
          on={profile.reminders}
          onChange={(v) => setProfile({ ...profile, reminders: v })}
        />
      </section>

      <section className="card p-6 border-red-200 dark:border-red-900/50">
        <h2 className="font-bold text-lg text-red-600 mb-2">Danger zone</h2>
        <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
          Wipe all your data and start fresh.
        </p>
        <button
          onClick={reset}
          className="inline-flex items-center gap-2 bg-red-50 hover:bg-red-100 dark:bg-red-900/30 dark:hover:bg-red-900/50 text-red-700 dark:text-red-300 font-medium px-4 py-2 rounded-lg transition"
        >
          <Trash2 className="w-4 h-4" /> Reset all data
        </button>
      </section>
    </div>
  );
}

function ToggleRow({ icon: Icon, title, desc, on, onChange }: { icon: any; title: string; desc: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-4 py-2">
      <div className="flex items-start gap-3 flex-1 min-w-0">
        <div className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center flex-shrink-0">
          <Icon className="w-4 h-4" />
        </div>
        <div className="min-w-0">
          <div className="font-medium">{title}</div>
          <div className="text-sm text-slate-500 dark:text-slate-400">{desc}</div>
        </div>
      </div>
      <button
        role="switch"
        aria-checked={on}
        onClick={() => onChange(!on)}
        className={`relative w-11 h-6 rounded-full transition flex-shrink-0 ${on ? "bg-brand-600" : "bg-slate-300 dark:bg-slate-700"}`}
      >
        <span
          className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${on ? "translate-x-5" : ""}`}
        />
      </button>
    </div>
  );
}
