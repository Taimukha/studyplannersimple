import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { useLocalStorage, uid, DAYS } from "../lib/storage";

export type Block = {
  id: string;
  day: number; // 0 = Mon
  start: string; // HH:MM
  end: string;
  subject: string;
  notes?: string;
};

export default function Schedule() {
  const [blocks, setBlocks] = useLocalStorage<Block[]>("sp_blocks", []);
  const [form, setForm] = useState<Omit<Block, "id">>({ day: 0, start: "09:00", end: "10:00", subject: "", notes: "" });

  const todayIdx = (new Date().getDay() + 6) % 7;

  function add(e: React.FormEvent) {
    e.preventDefault();
    if (!form.subject.trim()) return;
    setBlocks([...blocks, { id: uid(), ...form, subject: form.subject.trim() }]);
    setForm({ ...form, subject: "", notes: "" });
  }

  function remove(id: string) {
    setBlocks(blocks.filter((b) => b.id !== id));
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold">Weekly Schedule</h1>
        <p className="text-slate-600 dark:text-slate-400 mt-1">Block out study time across the week.</p>
      </header>

      <form onSubmit={add} className="card p-5 grid sm:grid-cols-12 gap-3">
        <select
          className="input sm:col-span-2"
          value={form.day}
          onChange={(e) => setForm({ ...form, day: Number(e.target.value) })}
        >
          {DAYS.map((d, i) => (
            <option key={d} value={i}>{d}</option>
          ))}
        </select>
        <input
          type="time"
          className="input sm:col-span-2"
          value={form.start}
          onChange={(e) => setForm({ ...form, start: e.target.value })}
        />
        <input
          type="time"
          className="input sm:col-span-2"
          value={form.end}
          onChange={(e) => setForm({ ...form, end: e.target.value })}
        />
        <input
          className="input sm:col-span-3"
          placeholder="Subject"
          value={form.subject}
          onChange={(e) => setForm({ ...form, subject: e.target.value })}
        />
        <input
          className="input sm:col-span-2"
          placeholder="Notes"
          value={form.notes}
          onChange={(e) => setForm({ ...form, notes: e.target.value })}
        />
        <button className="btn-primary sm:col-span-1" type="submit">
          <Plus className="w-4 h-4" />
        </button>
      </form>

      <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
        {DAYS.map((day, i) => {
          const dayBlocks = blocks
            .filter((b) => b.day === i)
            .sort((a, b) => a.start.localeCompare(b.start));
          const isToday = i === todayIdx;
          return (
            <div
              key={day}
              className={`card p-4 min-h-[200px] ${
                isToday ? "ring-2 ring-brand-500 shadow-soft" : ""
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <h3 className={`font-bold text-sm ${isToday ? "text-brand-600 dark:text-brand-400" : ""}`}>
                  {day}
                </h3>
                {isToday && (
                  <span className="text-[10px] font-semibold uppercase tracking-wider bg-brand-600 text-white px-1.5 py-0.5 rounded">
                    Today
                  </span>
                )}
              </div>
              {dayBlocks.length === 0 ? (
                <p className="text-xs text-slate-400 dark:text-slate-600 text-center py-6">No blocks</p>
              ) : (
                <ul className="space-y-2">
                  {dayBlocks.map((b) => (
                    <li
                      key={b.id}
                      className="group p-2 rounded-lg bg-brand-50 dark:bg-brand-900/20 border-l-2 border-brand-500 text-xs"
                    >
                      <div className="flex justify-between items-start gap-1">
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-brand-800 dark:text-brand-200">{b.subject}</div>
                          <div className="text-brand-600 dark:text-brand-400">{b.start} – {b.end}</div>
                          {b.notes && <div className="text-slate-600 dark:text-slate-400 mt-1 truncate">{b.notes}</div>}
                        </div>
                        <button
                          onClick={() => remove(b.id)}
                          className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500"
                          aria-label="Delete"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
