import { useState } from "react";
import { Plus, Trash2, Check, BookOpen } from "lucide-react";
import { useLocalStorage, uid } from "../lib/storage";

export type Task = {
  id: string;
  title: string;
  subject: string;
  priority: "low" | "medium" | "high";
  due?: string;
  completed: boolean;
  completedAt?: string;
  createdAt: string;
};

type Filter = "all" | "active" | "done";

export default function Tasks() {
  const [tasks, setTasks] = useLocalStorage<Task[]>("sp_tasks", []);
  const [filter, setFilter] = useState<Filter>("all");
  const [form, setForm] = useState({ title: "", subject: "", priority: "medium" as Task["priority"], due: "" });

  function add(e: React.FormEvent) {
    e.preventDefault();
    if (!form.title.trim()) return;
    setTasks([
      {
        id: uid(),
        title: form.title.trim(),
        subject: form.subject.trim() || "General",
        priority: form.priority,
        due: form.due || undefined,
        completed: false,
        createdAt: new Date().toISOString(),
      },
      ...tasks,
    ]);
    setForm({ title: "", subject: "", priority: "medium", due: "" });
  }

  function toggle(id: string) {
    setTasks(tasks.map((t) => (t.id === id ? { ...t, completed: !t.completed, completedAt: !t.completed ? new Date().toISOString() : undefined } : t)));
  }

  function remove(id: string) {
    setTasks(tasks.filter((t) => t.id !== id));
  }

  const filtered = tasks.filter((t) => (filter === "active" ? !t.completed : filter === "done" ? t.completed : true));

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold">Tasks</h1>
        <p className="text-slate-600 dark:text-slate-400 mt-1">Capture every assignment, reading, and prep session.</p>
      </header>

      <form onSubmit={add} className="card p-5 grid sm:grid-cols-12 gap-3">
        <input
          className="input sm:col-span-4"
          placeholder="Task title (e.g. Read Chapter 5)"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
        />
        <input
          className="input sm:col-span-3"
          placeholder="Subject"
          value={form.subject}
          onChange={(e) => setForm({ ...form, subject: e.target.value })}
        />
        <select
          className="input sm:col-span-2"
          value={form.priority}
          onChange={(e) => setForm({ ...form, priority: e.target.value as Task["priority"] })}
        >
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
        <input
          type="date"
          className="input sm:col-span-2"
          value={form.due}
          onChange={(e) => setForm({ ...form, due: e.target.value })}
        />
        <button className="btn-primary sm:col-span-1" type="submit">
          <Plus className="w-4 h-4" />
        </button>
      </form>

      <div className="flex gap-2">
        {(["all", "active", "done"] as Filter[]).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium capitalize transition ${
              filter === f
                ? "bg-brand-600 text-white"
                : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-brand-400"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="card p-12 text-center">
          <BookOpen className="w-12 h-12 mx-auto text-slate-300 dark:text-slate-700 mb-3" />
          <p className="text-slate-500 dark:text-slate-400">No tasks here yet. Add your first one above.</p>
        </div>
      ) : (
        <ul className="grid sm:grid-cols-2 gap-3">
          {filtered.map((t) => (
            <li key={t.id} className={`card p-4 hover:shadow-soft transition group ${t.completed ? "opacity-60" : ""}`}>
              <div className="flex items-start gap-3">
                <button
                  onClick={() => toggle(t.id)}
                  className={`mt-0.5 w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 transition ${
                    t.completed
                      ? "bg-brand-600 border-brand-600 text-white"
                      : "border-slate-300 dark:border-slate-600 hover:border-brand-500"
                  }`}
                  aria-label="Toggle complete"
                >
                  {t.completed && <Check className="w-3 h-3" />}
                </button>
                <div className="flex-1 min-w-0">
                  <div className={`font-semibold ${t.completed ? "line-through" : ""}`}>{t.title}</div>
                  <div className="flex flex-wrap items-center gap-2 mt-1.5">
                    <span className="text-xs px-2 py-0.5 rounded bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300">
                      {t.subject}
                    </span>
                    <span className={`text-xs px-2 py-0.5 rounded ${
                      t.priority === "high" ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300" :
                      t.priority === "medium" ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300" :
                      "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400"
                    }`}>
                      {t.priority}
                    </span>
                    {t.due && (
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        Due {new Date(t.due).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => remove(t.id)}
                  className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500 transition"
                  aria-label="Delete"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
