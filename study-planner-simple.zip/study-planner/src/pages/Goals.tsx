import { Target, CheckCircle2, Clock } from "lucide-react";
import { useLocalStorage, startOfWeek, endOfWeek } from "../lib/storage";
import type { Task } from "./Tasks";
import type { Block } from "./Schedule";

export type Goal = { tasks: number; hours: number };

export default function Goals() {
  const [goals, setGoals] = useLocalStorage<Goal>("sp_goals", { tasks: 10, hours: 15 });
  const [tasks] = useLocalStorage<Task[]>("sp_tasks", []);
  const [blocks] = useLocalStorage<Block[]>("sp_blocks", []);

  const start = startOfWeek();
  const end = endOfWeek();
  const completedThisWeek = tasks.filter(
    (t) => t.completed && t.completedAt && new Date(t.completedAt) >= start && new Date(t.completedAt) < end,
  ).length;
  const scheduledHours = blocks.reduce((sum, b) => {
    const [sh, sm] = b.start.split(":").map(Number);
    const [eh, em] = b.end.split(":").map(Number);
    return sum + Math.max(0, eh + em / 60 - (sh + sm / 60));
  }, 0);

  const tPct = Math.min(100, (completedThisWeek / Math.max(1, goals.tasks)) * 100);
  const hPct = Math.min(100, (scheduledHours / Math.max(1, goals.hours)) * 100);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold">Weekly Goals</h1>
        <p className="text-slate-600 dark:text-slate-400 mt-1">Set targets, track progress.</p>
      </header>

      <div className="grid md:grid-cols-2 gap-5">
        <GoalCard
          icon={CheckCircle2}
          title="Tasks completed"
          done={completedThisWeek}
          target={goals.tasks}
          pct={tPct}
          unit="tasks"
          onChange={(v) => setGoals({ ...goals, tasks: v })}
        />
        <GoalCard
          icon={Clock}
          title="Study hours"
          done={Number(scheduledHours.toFixed(1))}
          target={goals.hours}
          pct={hPct}
          unit="hrs"
          onChange={(v) => setGoals({ ...goals, hours: v })}
        />
      </div>

      <section className="card p-6">
        <h2 className="font-bold text-lg mb-4 flex items-center gap-2">
          <Target className="w-5 h-5 text-brand-600" />
          This week at a glance
        </h2>
        <div className="grid sm:grid-cols-3 gap-4 text-center">
          <Stat label="Done" value={completedThisWeek} color="text-emerald-600" />
          <Stat label="Remaining" value={Math.max(0, goals.tasks - completedThisWeek)} color="text-amber-600" />
          <Stat label="Scheduled hrs" value={scheduledHours.toFixed(1)} color="text-brand-600" />
        </div>
      </section>
    </div>
  );
}

function GoalCard({
  icon: Icon,
  title,
  done,
  target,
  pct,
  unit,
  onChange,
}: {
  icon: any;
  title: string;
  done: number;
  target: number;
  pct: number;
  unit: string;
  onChange: (v: number) => void;
}) {
  return (
    <div className="card p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 flex items-center justify-center">
          <Icon className="w-5 h-5" />
        </div>
        <h3 className="font-bold">{title}</h3>
      </div>

      <div className="flex items-end justify-between mb-2">
        <div>
          <span className="text-4xl font-extrabold">{done}</span>
          <span className="text-slate-400 text-lg"> / {target} {unit}</span>
        </div>
        <span className="text-2xl font-bold text-brand-600">{Math.round(pct)}%</span>
      </div>

      <div className="h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden mb-4">
        <div
          className="h-full bg-gradient-to-r from-brand-500 to-brand-600 rounded-full transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>

      <label className="text-xs text-slate-500 dark:text-slate-400 block mb-1">Weekly target</label>
      <input
        type="number"
        min={1}
        className="input"
        value={target}
        onChange={(e) => onChange(Math.max(1, Number(e.target.value) || 1))}
      />
    </div>
  );
}

function Stat({ label, value, color }: { label: string; value: any; color: string }) {
  return (
    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50">
      <div className={`text-3xl font-bold ${color}`}>{value}</div>
      <div className="text-sm text-slate-600 dark:text-slate-400 mt-1">{label}</div>
    </div>
  );
}
