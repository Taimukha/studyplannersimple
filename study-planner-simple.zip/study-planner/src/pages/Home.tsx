import { Link } from "react-router-dom";
import { ArrowRight, CheckSquare, Calendar, Target, Sparkles } from "lucide-react";
import { useLocalStorage, startOfWeek, endOfWeek } from "../lib/storage";
import hero from "../assets/hero.png";
import type { Task } from "./Tasks";
import type { Block } from "./Schedule";
import type { Goal } from "./Goals";

export default function Home() {
  const [profile] = useLocalStorage<{ name: string }>("sp_profile", { name: "" });
  const [tasks] = useLocalStorage<Task[]>("sp_tasks", []);
  const [blocks] = useLocalStorage<Block[]>("sp_blocks", []);
  const [goals] = useLocalStorage<Goal>("sp_goals", { tasks: 10, hours: 15 });

  const start = startOfWeek();
  const end = endOfWeek();
  const weekTasks = tasks.filter(
    (t) => t.completed && t.completedAt && new Date(t.completedAt) >= start && new Date(t.completedAt) < end,
  );
  const weekHours = blocks.reduce((sum, b) => {
    const [sh, sm] = b.start.split(":").map(Number);
    const [eh, em] = b.end.split(":").map(Number);
    return sum + Math.max(0, eh + em / 60 - (sh + sm / 60));
  }, 0);

  const today = new Date().toDateString();
  const todayTasks = tasks.filter((t) => !t.completed && t.due && new Date(t.due).toDateString() === today);

  const tasksPct = Math.min(100, Math.round((weekTasks.length / Math.max(1, goals.tasks)) * 100));
  const hoursPct = Math.min(100, Math.round((weekHours / Math.max(1, goals.hours)) * 100));

  return (
    <div className="space-y-8">
      {/* Hero */}
      <section className="card overflow-hidden">
        <div className="grid md:grid-cols-2 items-center">
          <div className="p-8 md:p-12">
            <div className="inline-flex items-center gap-2 bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300 px-3 py-1 rounded-full text-xs font-semibold mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              Your study, organized
            </div>
            <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight leading-tight">
              {profile.name ? `Welcome back, ${profile.name}.` : "Plan smart."}
              <br />
              <span className="text-brand-600">Study better.</span>
            </h1>
            <p className="mt-4 text-slate-600 dark:text-slate-400 text-lg">
              Track tasks, build a weekly schedule, and hit your study goals — all in one calm, focused place.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link to="/tasks" className="btn-primary">
                View Tasks <ArrowRight className="w-4 h-4" />
              </Link>
              <Link to="/goals" className="btn-ghost border border-slate-200 dark:border-slate-700">
                Set Goals
              </Link>
            </div>
          </div>
          <div className="hidden md:block h-full">
            <img src={hero} alt="Student studying" className="w-full h-full object-cover" />
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="grid sm:grid-cols-3 gap-4">
        <StatCard icon={CheckSquare} label="Today's Tasks" value={todayTasks.length} hint="Due today" to="/tasks" />
        <StatCard icon={Target} label="Tasks Goal" value={`${tasksPct}%`} hint={`${weekTasks.length} / ${goals.tasks} done`} to="/goals" pct={tasksPct} />
        <StatCard icon={Calendar} label="Hours Goal" value={`${hoursPct}%`} hint={`${weekHours.toFixed(1)} / ${goals.hours} hrs`} to="/goals" pct={hoursPct} />
      </section>

      {/* Today */}
      <section className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Due today</h2>
          <Link to="/tasks" className="text-sm text-brand-600 hover:text-brand-700 font-medium flex items-center gap-1">
            All tasks <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
        {todayTasks.length === 0 ? (
          <p className="text-slate-500 dark:text-slate-400 text-sm py-8 text-center">
            Nothing due today. Enjoy the breathing room.
          </p>
        ) : (
          <ul className="space-y-2">
            {todayTasks.map((t) => (
              <li key={t.id} className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                <div>
                  <div className="font-medium">{t.title}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{t.subject}</div>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  t.priority === "high" ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300" :
                  t.priority === "medium" ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300" :
                  "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                }`}>
                  {t.priority}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, hint, to, pct }: { icon: any; label: string; value: any; hint: string; to: string; pct?: number }) {
  return (
    <Link to={to} className="card p-6 hover:shadow-soft hover:-translate-y-0.5 transition-all block">
      <div className="flex items-start justify-between mb-3">
        <div className="w-10 h-10 rounded-lg bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 flex items-center justify-center">
          <Icon className="w-5 h-5" />
        </div>
      </div>
      <div className="text-3xl font-bold">{value}</div>
      <div className="text-sm text-slate-600 dark:text-slate-400 mt-1">{label}</div>
      <div className="text-xs text-slate-500 dark:text-slate-500 mt-2">{hint}</div>
      {pct !== undefined && (
        <div className="mt-3 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
          <div className="h-full bg-brand-600 transition-all" style={{ width: `${pct}%` }} />
        </div>
      )}
    </Link>
  );
}
